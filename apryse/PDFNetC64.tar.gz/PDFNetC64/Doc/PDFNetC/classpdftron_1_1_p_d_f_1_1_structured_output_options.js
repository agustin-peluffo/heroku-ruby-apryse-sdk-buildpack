var classpdftron_1_1_p_d_f_1_1_structured_output_options =
[
    [ "SectionConversionSetting", "classpdftron_1_1_p_d_f_1_1_structured_output_options.html#ad2a68a6913180ed4e6e889f7d5848377", [
      [ "e_Recover", "classpdftron_1_1_p_d_f_1_1_structured_output_options.html#ad2a68a6913180ed4e6e889f7d5848377ad6ec25ac9996ca77395a410485c03c4d", null ],
      [ "e_DoNotDetect", "classpdftron_1_1_p_d_f_1_1_structured_output_options.html#ad2a68a6913180ed4e6e889f7d5848377a710569870bfd3233b45a5bf523ff2441", null ],
      [ "e_DetectAndRemove", "classpdftron_1_1_p_d_f_1_1_structured_output_options.html#ad2a68a6913180ed4e6e889f7d5848377aa97b4fe4eaa4db9bc72d35e47a742853", null ]
    ] ],
    [ "SectionConversionSettingFromOption", "classpdftron_1_1_p_d_f_1_1_structured_output_options.html#ac32aea407a600bdfb56a14b0c36f6ce5", null ]
];