var classpdftron_1_1_p_d_f_1_1_link_info =
[
    [ "rect", "classpdftron_1_1_p_d_f_1_1_link_info.html#aed0fb9bdc669f6d2d7f4516dd776ee88", null ],
    [ "url", "classpdftron_1_1_p_d_f_1_1_link_info.html#af42a118c6e2544d57bd0ba2104ab1f4d", null ]
];