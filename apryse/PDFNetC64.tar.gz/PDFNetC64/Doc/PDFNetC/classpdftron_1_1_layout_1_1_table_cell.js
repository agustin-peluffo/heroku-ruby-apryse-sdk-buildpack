var classpdftron_1_1_layout_1_1_table_cell =
[
    [ "CellAlignmentHorizontal", "classpdftron_1_1_layout_1_1_table_cell.html#a797575b4e881c4f5f894afa691aae163", [
      [ "e_alignment_left", "classpdftron_1_1_layout_1_1_table_cell.html#a797575b4e881c4f5f894afa691aae163a8e9e23c5885c8fdcc14a90089b9459eb", null ],
      [ "e_alignment_middle", "classpdftron_1_1_layout_1_1_table_cell.html#a797575b4e881c4f5f894afa691aae163a46ac2349bb205791014d419ee4605c50", null ],
      [ "e_alignment_right", "classpdftron_1_1_layout_1_1_table_cell.html#a797575b4e881c4f5f894afa691aae163aead3a1a11b1f645fba0d7edd266c9574", null ]
    ] ],
    [ "CellAlignmentVertical", "classpdftron_1_1_layout_1_1_table_cell.html#aa8975bf8020624d6d4049b48ff2e423c", [
      [ "e_alignment_top", "classpdftron_1_1_layout_1_1_table_cell.html#aa8975bf8020624d6d4049b48ff2e423ca51611dfc8fdb0ee2144268a435e25649", null ],
      [ "e_alignment_center", "classpdftron_1_1_layout_1_1_table_cell.html#aa8975bf8020624d6d4049b48ff2e423ca6db1570d9133c13c0ed4f11ea09d52cf", null ],
      [ "e_alignment_bottom", "classpdftron_1_1_layout_1_1_table_cell.html#aa8975bf8020624d6d4049b48ff2e423ca12073120bc01a131190026efef3039eb", null ]
    ] ],
    [ "~TableCell", "classpdftron_1_1_layout_1_1_table_cell.html#a3ec27c1bbe1cfb991f08f4a97bdc03d4", null ],
    [ "AddParagraph", "classpdftron_1_1_layout_1_1_table_cell.html#a2f1749a84942a5ffa3031c52c6f7af0f", null ],
    [ "AddParagraph", "classpdftron_1_1_layout_1_1_table_cell.html#a2bafc7a3b40b69afaec25dbc160c15e5", null ],
    [ "AddTable", "classpdftron_1_1_layout_1_1_table_cell.html#ab8e42817a8378c11fc59edc6b1068e41", null ],
    [ "Destroy", "classpdftron_1_1_layout_1_1_table_cell.html#a75c6c83cf2b43573eb851a87fc0b2dc1", null ],
    [ "GetBorderThickness", "classpdftron_1_1_layout_1_1_table_cell.html#ad5a3c50b8d241274bc8c5e3da60841a7", null ],
    [ "GetHeight", "classpdftron_1_1_layout_1_1_table_cell.html#afb41ca435749e4a18f7343bf333658ac", null ],
    [ "GetHorizontalAlignment", "classpdftron_1_1_layout_1_1_table_cell.html#a1a5d74095349c820bb7ed1705ba65766", null ],
    [ "GetVerticalAlignment", "classpdftron_1_1_layout_1_1_table_cell.html#a159d897073f7dc0e5a097395d2708a82", null ],
    [ "GetWidth", "classpdftron_1_1_layout_1_1_table_cell.html#ac538d33bc598632f30cefa776361c447", null ],
    [ "MergeCellsDown", "classpdftron_1_1_layout_1_1_table_cell.html#a16b8dca36265669454e4fe483415ef1e", null ],
    [ "MergeCellsRight", "classpdftron_1_1_layout_1_1_table_cell.html#acff27ddf0f2bd5fdcbb1e68deaeb2933", null ],
    [ "SetBackgroundColor", "classpdftron_1_1_layout_1_1_table_cell.html#a981f3deb96939e9482423e7b0498103d", null ],
    [ "SetBorder", "classpdftron_1_1_layout_1_1_table_cell.html#a09070d120b7a8a47fd3265e63f99f602", null ],
    [ "SetHeight", "classpdftron_1_1_layout_1_1_table_cell.html#ac60535056ddfc5a1236a59b49d80df9b", null ],
    [ "SetHorizontalAlignment", "classpdftron_1_1_layout_1_1_table_cell.html#ac4b86ae209f093970717907937d9c4e8", null ],
    [ "SetVerticalAlignment", "classpdftron_1_1_layout_1_1_table_cell.html#a81a6de2819d9d52b77db42b67fab05f6", null ],
    [ "SetWidth", "classpdftron_1_1_layout_1_1_table_cell.html#ac44b37aaf95c14f51fe321573fbe61a9", null ],
    [ "ElementRef< TableCell >", "classpdftron_1_1_layout_1_1_table_cell.html#a115c5bfcf4129a5258ebfbacba14ee10", null ],
    [ "Table", "classpdftron_1_1_layout_1_1_table_cell.html#af888815e80064bc9fa1035c6265da86e", null ],
    [ "TableRow", "classpdftron_1_1_layout_1_1_table_cell.html#a2a150b6fa0ac938b7b9b0c896ba13e5e", null ]
];