var dir_4ab6b4cc6a7edbff49100e9123df213f =
[
    [ "BasicTypes.h", "_basic_types_8h.html", "_basic_types_8h" ],
    [ "ByteRange.h", "_byte_range_8h.html", [
      [ "ByteRange", "classpdftron_1_1_common_1_1_byte_range.html", "classpdftron_1_1_common_1_1_byte_range" ]
    ] ],
    [ "Common.h", "_common_8h.html", "_common_8h" ],
    [ "Exception.h", "_exception_8h.html", "_exception_8h" ],
    [ "Iterator.h", "_iterator_8h.html", [
      [ "Iterator", "classpdftron_1_1_common_1_1_iterator.html", "classpdftron_1_1_common_1_1_iterator" ],
      [ "Iterator< int >", "classpdftron_1_1_common_1_1_iterator_3_01int_01_4.html", "classpdftron_1_1_common_1_1_iterator_3_01int_01_4" ]
    ] ],
    [ "Matrix2D.h", "_matrix2_d_8h.html", [
      [ "Matrix2D", "classpdftron_1_1_common_1_1_matrix2_d.html", "classpdftron_1_1_common_1_1_matrix2_d" ]
    ] ],
    [ "RecentlyUsedCache.h", "_recently_used_cache_8h.html", [
      [ "RecentlyUsedCache", "classpdftron_1_1_common_1_1_recently_used_cache.html", "classpdftron_1_1_common_1_1_recently_used_cache" ]
    ] ],
    [ "UString.h", "_u_string_8h.html", "_u_string_8h" ]
];